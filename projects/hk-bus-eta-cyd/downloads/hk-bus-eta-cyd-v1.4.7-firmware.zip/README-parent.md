# HK Bus ETA CYD — 座枱巴士實時報站

用 **ESP32-2432S028（Cheap Yellow Display）** 做座枱報站器：手機經 Wi‑Fi 設定站點／路線，板子顯示九巴（KMB/LWB）同城巴（CTB）實時 ETA。

| 項目 | 內容 |
|------|------|
| 硬件 | ESP32-2432S028（2.8" 240×320、電阻觸控、microSD） |
| 數據 | [九巴 ETA](https://data.gov.hk/tc-data/dataset/hk-td-tis_21-etakmb)、[城巴 ETA](https://data.gov.hk/tc-data/dataset/ctb-eta-transport-realtime-eta) |
| 狀態 | **計劃階段** — 等你同意後先至寫 firmware |
| 文檔 | `docs/FEASIBILITY.md` · `docs/PLAN.md` · `docs/API_NOTES.md` · `docs/ARCHITECTURE.md` |

## 一句結論

**可行。** 政府 API 已實測可用；瓶頸在儲存（全港站點 DB 建議放 microSD）、城巴站點清單要由路線展開組建、以及板子**無內建電池管理**（要外接或先當 USB 常插）。

## 目錄

```
hk-bus-eta-cyd/
├── README.md
└── docs/
    ├── FEASIBILITY.md
    ├── PLAN.md
    ├── API_NOTES.md
    └── ARCHITECTURE.md
```
